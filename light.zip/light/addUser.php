<?php include_once 'elements/header.php'; ?>
<?php include_once 'elements/nav_ber.php'; ?>
<?php include_once 'elements/side_bar.php'; ?>


			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Add User</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Users</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Add User</li>
							</ol>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="card card-box">
								<div class="card-head">
									<header>Basic Information</header>
								</div>

								 <?php
                                            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                                                $username = mysqli_escape_string(db_con(), $_POST['username']);
                                                $email = mysqli_escape_string(db_con(), $_POST['email']);
                                                $pass = mysqli_escape_string(db_con(), md5($_POST['pass']));
                                                $ac_year = date_format(date_create($_POST['ac_year']),'Y-m-d');
                                                $address = mysqli_escape_string(db_con(), $_POST['address']);
                                                $mobile = mysqli_escape_string(db_con(), $_POST['mobile']);
                                                $faculty_id = mysqli_escape_string(db_con(), $_POST['faculty_id']);
                                                $role_id = mysqli_escape_string(db_con(), $_POST['role_id']);
                                               


                                                $permited = array('jpg','PNG','jpeg','gif');
                                                $image_name = $_FILES['image']['name'];
                                                $image_size = $_FILES['image']['size'];
                                                $image_tamp = $_FILES['image']['tmp_name'];

                                                $divied = explode('.', $image_name);
                                                $extention = strtolower(end($divied));
                                                $uniq_name =substr( md5(time()), 0,10).'.'.$extention;
                                                $uploaded_image = "img/profile/".$uniq_name;


                                                if ($username == "" || $email == "" || $pass == "" || $ac_year == "" || $address == "" || $mobile == "" || $faculty_id == "" || $role_id == "" ) {
                                                    echo "<span class='error'>Field Must not empty!!!</span>";
                                                }elseif ($image_size > 1048745) {
                                                    echo "<span class='error'>Image size must be less 1 MB!!!</span>";
                                                }else{
                                                    move_uploaded_file($image_tamp, $uploaded_image);
                                                    $query = "INSERT INTO users(username,email,pass,address,mobile, user_pic,ac_year,faculty_id,role_id)
                                                 VALUES('$username','$email','$pass','$address','$mobile','$uploaded_image','$ac_year','$faculty_id','$role_id')";
                                                 
                                                    $res = mysqli_query(db_con(), $query);
                                                    if ($res){
                                                        echo "<span class='success'>User Added Successfully.</span>";
                                                    }else {
                                                        echo "<span class='error'>Upload Failed  !!!</span>";
                                                    }
                                                }
                                            }

                                            ?>

								<div class="card-body" id="bar-parent">
									<form action="addUser.php" method="POST" enctype="multipart/form-data" class="form-horizontal">
										<div class="form-body">
											<div class="form-group row">
												<label class="control-label col-md-3">User Name
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<input type="text" name="username" placeholder="Enter user name" class="form-control input-height" required />
												</div>
											</div>
											
											
											<div class="form-group row">
												<label class="control-label col-md-3">Email
												</label>
												<div class="col-md-5">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="fa fa-envelope"></i>
														</span>
														<input type="email" class="form-control input-height" name="email" placeholder="Email Address" required> </div>
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">Password
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<input type="password" name="pass" placeholder="Enter password" class="form-control input-height" required />
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">Academic Year
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<div class="input-group date form_date " data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2"
													 data-link-format="yyyy-mm-dd">
														<input class="form-control input-height" name="ac_year" size="16" placeholder="Academic Year" type="text" value="" required>
														<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
													</div>
													<input type="hidden" id="dtp_input2" value="" required />
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">Address
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<textarea name="address" placeholder="address" class="form-control-textarea" rows="5" required></textarea>
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">Contact Number
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<input type="number" name="mobile" placeholder="Enter Mobile Number" class="form-control input-height" required />
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">Class
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<select class="form-control input-height" name="faculty_id" required>
														<option value="">Faculty ID</option>
														<option value="1">IT</option>
														<option value="2">BBA</option>
														<option value="3">CIS</option>
														<option value="4">CSE</option>
													</select>
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">User Type
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<select class="form-control input-height" name="role_id" required>
														<option value="">User Type</option>
														<option value="2">Marketing Coordinator</option>
														<option value="3">Marketing Coordinator</option>
														<option value="4">Student</option>
														<option value="5">Guest</option>
													</select>
												</div>
											</div>
											
											
										
											<div class="form-group row">
												<label class="control-label col-md-3">Profile Picture
												</label>
												<div class="compose-editor">
													<input type="file" class="default" name="image" multiple>
												</div>
											</div>
											<div class="form-actions">
												<div class="row">
													<div class="offset-md-3 col-md-9">
														<button type="submit" class="btn btn-info m-r-20">Submit</button>
														<button type="button" class="btn btn-default">Cancel</button>
													</div>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end page content -->
			<!-- start chat sidebar -->
			
<?php include_once 'elements/footer.php'; ?>