<?php define('BASE_URL', 'http://localhost/light/');?>
<?php session_start(); ?>
<?php 
	if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] == FALSE) {
		header('Location: login.php');
	}
	
?>

<?php include_once 'elements/header.php'; ?>
<?php include_once 'elements/nav_ber.php'; ?>
<?php include_once 'elements/side_bar.php'; ?>

<?php
if (isset($_GET['id'])){
    $cat_id=($_GET['id']);
    $SQL = "DELETE FROM catagory WHERE category_id='$cat_id'";
    $RESULT = mysqli_query(db_con(), $SQL);

    if($RESULT){
        $msg = "Data deleted Successfully";
    }else{
        $msg = "Data delete ERROR";
    }
}


?>


<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Category List</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Categories</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Category List</li>
							</ol>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-md-12 col-xl-12">
							<div class="card-box">
								<div class="card-head">
									<header>Category List</header>
								</div>

								<div class="card-body ">
                                    <?php
                                    if (isset ( $msg)){
                                        echo $msg;
                                    }
                                    ?>
									<div class="table-scrollable">
										<table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
											<thead>
												<tr>
													<th>Cat. Id</th>
													<th>Cat. Name</th>
													<th>Cat. Details</th>
													<th>Created Date</th>
													<th>Closure Date</th>
													<th>Final Closure Date</th>
													<th>Edit</th>
												</tr>
											</thead>
											<tbody>

                                            <?php
                                            $GET_USER_SQL = "SELECT * FROM `catagory`";
                                            $user =  mysqli_query(db_con(), $GET_USER_SQL);
                                            while ($row = mysqli_fetch_array($user)){
                                            ?>
												<tr class="odd">
                                                    <td><?php echo $row['category_id']; ?></td>
                                                    <td><?php echo $row['category_name']; ?></td>
                                                    <td><?php echo $row['category_desc']; ?></td>
                                                    <td><?php echo $row['created_date']; ?></td>
                                                    <td><?php echo $row['closure_date']; ?></td>
                                                    <td><?php echo $row['final_closure_date']; ?></td>
													<td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
															<i class="fa fa-check"></i></a> <a href="all_category.php?id=<?=$row['category_id'];?>" class="text-inverse" title="Delete"
														 data-toggle="tooltip">
															<i class="fa fa-trash"></i></a>
													</td>
												</tr>
                                            <?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end page content -->
			<!-- start chat sidebar -->
			<!-- end chat sidebar -->
		</div>
		<!-- end page container -->
		<!-- start footer -->

        <?php include_once 'elements/footer.php'; ?>
