<?php define('BASE_URL', 'http://localhost/light/');?>
<?php session_start(); ?>
<?php 
	if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] == FALSE) {
		header('Location: login.php');
	}
	
?>

<?php include_once 'elements/header.php'; ?>
<?php include_once 'elements/nav_ber.php'; ?>
<?php include_once 'elements/side_bar.php'; ?>

<?php
if (isset($_GET['id'])){
    $cont_id=($_GET['id']);
    $SQL = "DELETE FROM contents WHERE cont_id='$cont_id'";
    $RESULT = mysqli_query(db_con(), $SQL);

    if($RESULT){
        $msg = "Data deleted Successfully";
    }else{
        $msg = "Data delete ERROR";
    }
}

?>


<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Submission List</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Submissions</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Contents List</li>
							</ol>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-md-12 col-xl-12">
							<div class="card-box">
								<div class="card-head">
									<header>Contents List</header>
								</div>

								<div class="card-body ">
                                    <?php
                                    if (isset ( $msg)){
                                        echo $msg;
                                    }
                                    ?>
									<div class="table-scrollable">
										<table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
											<thead>
												<tr>
													<th>Cont. Id</th>
													<th>Cont. Title</th>
													<th>Cont. Details</th>
													<th>Category</th>
													<th>Post Time</th>
													<th>Content File</th>
													<th>Submitted By</th>
													<th>Edit</th>
												</tr>
											</thead>
											<tbody>

                                            <?php
                                            $GET_USER_SQL = "SELECT * FROM `contents`";
                                            $user =  mysqli_query(db_con(), $GET_USER_SQL);
                                            while ($row = mysqli_fetch_array($user)){
                                            ?>
												<tr class="odd">
                                                    <td><?php echo $row['cont_id']; ?></td>
                                                    <td><?php echo $row['cont_title']; ?></td>
                                                    <td><?php echo $row['cont_details']; ?></td>
                                                    <td><?php echo $row['category']; ?></td>
                                                    <td><?php echo $row['post_time']; ?></td>
                                                    <td><?=(!empty($row['file']))? str_replace('contents/', '', $row['file']).'<br><a href="all_contents.php?dwn='.$row['file'].'" class="btn btn-sm btn-primary downbtn">Download File</a>': 'File not added';?></td>
                                                    <td><?php echo $row['user_name']; ?></td>
													<td>

														<a href="view_content.php?viw=<?=$row['cont_id'];?>" class="" data-toggle="tooltip" title="Edit">
															<i class="fa fa-eye"></i>
														</a> 

														<a href="all_contents.php?id=<?=$row['cont_id'];?>" class="text-inverse" title="Delete"
														 data-toggle="tooltip">
															<i class="fa fa-trash"></i></a>
													</td>
												</tr>
                                            <?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end page content -->
			<!-- start chat sidebar -->
			<!-- end chat sidebar -->
		</div>
		<!-- end page container -->
		<!-- start footer -->
        <?php include_once 'elements/footer.php'; ?>

<?php
if (isset($_GET['dwn'])){
    error_reporting(0);

    $imgPath = $_GET['dwn'];

    $zip = new ZipArchive();

    $DelFilePath= "zips/".time()."file.zip";

    $zip->open($DelFilePath, ZipArchive::CREATE);
    $zip->addFile($imgPath);

    if ($zip->close()){
        echo '<script>
                window.location.href = "'.$DelFilePath.'";
              </script>';
    }else{
        $msg = 'Zipping is not working';
    }

    header('Content-Type: application/zip');
}
?>