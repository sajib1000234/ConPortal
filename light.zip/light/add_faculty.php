<?php define('BASE_URL', 'http://localhost/light/');?>
<?php session_start(); ?>
<?php 
	if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] == FALSE) {
		header('Location: login.php');
	}
	
?>


<?php include_once 'elements/header.php'; ?>
<?php include_once 'elements/nav_ber.php'; ?>
<?php include_once 'elements/side_bar.php'; ?>

    <div class="page-wrapper">
		<!-- start page container -->
		<div class="page-container">
			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Add New Faculty</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Content Types</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Add New Faculty</li>
							</ol>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="card card-box">
								<div class="card-head">
									<header>Add New Faculty</header>
								</div>
                                <?php
                                $msg = "";
                                if ($_SERVER['REQUEST_METHOD'] == "POST") {
                                    $faculty_name = mysqli_escape_string(db_con(), $_POST['faculty_name']);
                                     $faculty_details = mysqli_escape_string(db_con(), $_POST['faculty_details']);
                                    

                                    if ($faculty_name == "" || $faculty_details == "" ) {
                                        echo "<span class='error'>Field Must not be empty!!!</span>";
                                    }else{
                                        $sql = "INSERT IGNORE INTO faculty(faculty_name,faculty_details)
                             VALUES('$faculty_name','$faculty_details')";

                                        $res = mysqli_query(db_con(), $sql);
                                        if ($res){
                                            echo "<span class='success'>Faculty Added Successfully.
                             </span>";
                                        }else {
                                            echo "<span class='error'>Add Failed  !!!</span>";
                                        }
                                    }
                                }



                                ?>
								<div class="card-body" id="bar-parent">
									<form action="add_faculty.php" method="post" id="form_sample_1" class="form-horizontal">
										<div class="form-body">
											<div class="form-group row">
												<label class="control-label col-md-3">Faculty Name
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<input type="text" name="faculty_name" placeholder="Enter faculty name" class="form-control input-height" />
												</div>
											</div>
											<div class="form-group row">
												<label class="control-label col-md-3">Faculty Details
												</label>

												<div class="col-md-5">
													<textarea name="faculty_details" placeholder="Faculty details" style="border: 1px black solid" border-style="solid" class="form-control-textarea" rows="5"></textarea>
												</div>
											</div>
											
											<div class="form-actions">
												<div class="row">
													<div class="offset-md-3 col-md-9">
														<button type="submit" class="btn btn-info m-r-20">Submit</button>
														<button type="button" class="btn btn-default">Cancel</button>
													</div>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end page content -->
			<!-- start chat sidebar -->
			<!-- end chat sidebar -->
		</div>
		<!-- end page container -->
		<!-- start footer -->
<?php include_once 'elements/footer.php'; ?>