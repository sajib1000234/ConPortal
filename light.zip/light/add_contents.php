<?php define('BASE_URL', 'http://localhost/light/');?>
<?php session_start(); ?>
<?php 
	if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] == FALSE) {
		header('Location: login.php');
	}
	
?>

<?php include_once 'elements/header.php'; ?>
<?php include_once 'elements/nav_ber.php'; ?>
<?php include_once 'elements/side_bar.php'; ?>

<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Add Contents</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a class="parent-item" href="#">Contents</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Add Contents</li>
							</ol>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<div class="card card-box">
								<div class="card-head">
									<header>Contents Information</header>
								</div>
                                  <?php
                                            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                                                $cont_title = mysqli_escape_string(db_con(), $_POST['cont_title']);
                                                $category = mysqli_escape_string(db_con(), $_POST['category_name']);
                                                $cont_details = mysqli_escape_string(db_con(), $_POST['cont_details']);
                                                $user_id = $_SESSION['u_id'];
                                                $user_name = $_SESSION['name'];
                                                $date = date('Y-m-d H:i:s');


                                                // doc up


                                                $doc_permited = array('docx');
                                                $file_name = $_FILES['wordfile']['name'];
                                                $file_size = $_FILES['wordfile']['size'];
                                                $file_tamp = $_FILES['wordfile']['tmp_name'];

                                                $divied = explode('.', $file_name);
                                                $file_extention = strtolower(end($divied));
                                                $uniq_name =substr( md5(time()), 0,10).'.'.$file_extention;
                                                $uploaded_file = "contents/".$uniq_name;

                                                if ($cont_title == "" || $cont_details == "" || $category == "") {
                                                    echo "<span class='error'>Field Must not empty!!!</span>";
                                                }elseif (in_array($file_extention, $doc_permited) === false) {
                                                    echo "<span class='error'>You can upload only:-".implode(',', $doc_permited)."</span>";
                                                }else{
                                                    move_uploaded_file($file_tamp, $uploaded_file);
                                                    $query = "INSERT INTO contents(cont_title,cont_details,category,post_time,file, user_id,user_name)
                                                 VALUES('$cont_title','$cont_details','$category','$date','$uploaded_file','$user_id','$user_name')";
                                                    $res = mysqli_query(db_con(), $query);
                                                    if ($res){
                                                        echo "<span class='success'>Content Uploaded Successfully.</span>";
                                                    }else {
                                                        echo "<span class='error'>Upload Failed  !!!</span>";
                                                    }
                                                }
                                            }

                                            ?>

								<div class="card-body" id="bar-parent">
									<form action="add_contents.php" method="post" enctype="multipart/form-data" mid="form_sample_1" class="form-horizontal">
										<div class="form-body">
											<div class="form-group row">
												<label class="control-label col-md-3">Content Title
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<input type="text" name="cont_title" placeholder="enter content name" class="form-control input-height" />
												</div>
											</div>

											<div class="form-group row">
												<label class="control-label col-md-3">Categories
													<span class="required"> * </span>
												</label>
												<div class="col-md-5">
													<select class="form-control input-height" name="category_name">
                                                        <option value="">Select...</option>
                                                        <?php
                                                        $sqld = "SELECT category_name FROM catagory"; // WHERE DATE (ideas_closer_date) > DATE(now())";
                                                        $dnres = mysqli_query(db_con(), $sqld);

                                                        while ($category = mysqli_fetch_array($dnres)){
                                                            ?>
                                                            <option value="<?=$category['category_name'];?>"><?=$category['category_name'];?></option>
                                                        <?php }?>
													</select>
												</div>
											</div>
                                            <div class="form-group row">
                                                <label class="control-label col-md-3">Details
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-5">

                                                    <textarea name="cont_details" placeholder="address" class="form-control" rows="5"></textarea>
                                                </div>
                                            </div>
											<div class="form-group row">
												<label class="control-label col-md-3">Upload File
												</label>
												<div class="compose-editor">
													<input type="file" id="wordfile" name="wordfile" class="default" multiple>
												</div>
											</div>
											<div class="form-actions">
												<div class="row">
													<div class="offset-md-3 col-md-9">
														<button type="submit" class="btn btn-info m-r-20">Submit</button>
														<button type="button" class="btn btn-default">Cancel</button>
													</div>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end page content -->
			<!-- start chat sidebar -->
			<!-- end chat sidebar -->
	<?php include_once 'elements/footer.php'; ?>